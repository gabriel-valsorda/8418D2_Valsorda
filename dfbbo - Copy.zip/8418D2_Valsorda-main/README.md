# Derivative-Free and Blackbox Optimization

Repository for the book of Audet and Hare

### How to cite

```
@book{AuHa2017,
  Author    = {C. Audet and W. Hare},
  Title     = {{Derivative-Free and Blackbox Optimization}},
  Series    = {Springer Series in Operations Research and Financial Engineering},
  Year      = {2017},
  Publisher = {Springer},
  Address   = {Cham, Switzerland},
  Doi       = {10.1007/978-3-319-68913-5},
  Url       = {https://dx.doi.org/10.1007/978-3-319-68913-5}
}
```
